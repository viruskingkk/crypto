@echo off
chcp 65001 >nul
cd /d "%~dp0"
start http://127.0.0.1:8765/%E8%99%9B%E6%93%AC%E8%B2%A8%E5%B9%A3%E5%85%AD%E8%84%88%E7%A5%9E%E5%8A%8D%E9%81%B8%E5%B9%A3%E7%B3%BB%E7%B5%B1.html
python -m http.server 8765 --bind 127.0.0.1
pause
