#!/usr/bin/env python3
import argparse, csv, time, urllib.request, json, datetime
CATMAP={'BTC':'主流幣','ETH':'主流幣','BNB':'平台幣','SOL':'公鏈','XRP':'支付','ADA':'公鏈','DOGE':'迷因幣','TRX':'公鏈','LINK':'Oracle','AVAX':'公鏈','DOT':'公鏈','MATIC':'Layer2','POL':'Layer2','TON':'公鏈','LTC':'主流幣','BCH':'主流幣','UNI':'DeFi','NEAR':'公鏈','APT':'公鏈','ARB':'Layer2','OP':'Layer2','ETC':'主流幣','FIL':'儲存','ATOM':'公鏈','INJ':'DeFi','SUI':'公鏈','SEI':'公鏈','AAVE':'DeFi','RNDR':'AI/算力','RENDER':'AI/算力','PEPE':'迷因幣','SHIB':'迷因幣'}
def base_of(sym):
    for q in ['USDT','USDC','BTC','ETH','FDUSD','TUSD']:
        if sym.endswith(q): return sym[:-len(q)]
    return sym
def cat_of(sym): return CATMAP.get(base_of(sym),'其他')
def fetch(symbol, interval, limit):
    url=f'https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}'
    with urllib.request.urlopen(url, timeout=20) as r:
        return json.loads(r.read().decode())
def iso(ms):
    return datetime.datetime.utcfromtimestamp(ms/1000).replace(microsecond=0).isoformat()+'Z'
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--symbols',default='BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT,XRPUSDT,ADAUSDT,DOGEUSDT,TRXUSDT,LINKUSDT,AVAXUSDT,DOTUSDT,MATICUSDT,TONUSDT,LTCUSDT,BCHUSDT,UNIUSDT,NEARUSDT,APTUSDT,ARBUSDT,OPUSDT')
    ap.add_argument('--intervals',default='1m,15m,1h,4h,1d')
    ap.add_argument('--limit',type=int,default=0,help='所有週期共用筆數；0 表示使用各週期預設')
    ap.add_argument('--limit-1m',dest='limit_1m',type=int,default=500)
    ap.add_argument('--limit-15m',dest='limit_15m',type=int,default=500)
    ap.add_argument('--limit-1h',dest='limit_1h',type=int,default=500)
    ap.add_argument('--limit-4h',dest='limit_4h',type=int,default=300)
    ap.add_argument('--limit-1d',dest='limit_1d',type=int,default=300)
    ap.add_argument('--sleep',type=float,default=0.25)
    ap.add_argument('--out',default='crypto_history_multi.csv')
    args=ap.parse_args()
    symbols=[s.strip().upper() for s in args.symbols.split(',') if s.strip()]
    intervals=[s.strip() for s in args.intervals.split(',') if s.strip()]
    fields=['symbol','base','quote','category','interval','date','open','high','low','close','volume','quote_volume','trades']
    with open(args.out,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        total=len(symbols)*len(intervals); n=0
        for sym in symbols:
            for itv in intervals:
                n+=1
                try:
                    limit = args.limit if args.limit and args.limit > 0 else {'1m':args.limit_1m,'15m':args.limit_15m,'1h':args.limit_1h,'4h':args.limit_4h,'1d':args.limit_1d}.get(itv,300)
                    rows=fetch(sym,itv,limit)
                    for k in rows:
                        w.writerow({'symbol':sym,'base':base_of(sym),'quote':'USDT','category':cat_of(sym),'interval':itv,'date':iso(k[0]),'open':k[1],'high':k[2],'low':k[3],'close':k[4],'volume':k[5],'quote_volume':k[7],'trades':k[8]})
                    warn = ' WARN(<80)' if len(rows) < 80 else ''
                    print(f'[{n}/{total}] {sym} {itv} OK ({len(rows)}/{limit}){warn}')
                except Exception as e:
                    print(f'[{n}/{total}] {sym} {itv} FAIL: {e}')
                time.sleep(args.sleep)
    print('done:', args.out)
if __name__=='__main__': main()
