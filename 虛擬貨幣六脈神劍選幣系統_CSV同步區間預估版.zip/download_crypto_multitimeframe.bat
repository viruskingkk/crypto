@echo off
chcp 65001 > nul
python crypto_multitimeframe_downloader.py --out crypto_history_multi.csv --sleep 0.25 --limit-1m 500 --limit-15m 500 --limit-1h 500 --limit-4h 300 --limit-1d 300
pause
