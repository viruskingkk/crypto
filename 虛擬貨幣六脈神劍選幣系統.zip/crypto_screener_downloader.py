#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密貨幣版離線資料下載器
輸出 crypto_history.csv，可直接匯入 HTML 使用。
資料來源：Binance Spot public REST API，無需 API key。
"""
import argparse, csv, time, json, urllib.request, urllib.parse
from datetime import datetime, timezone

BASE = "https://api.binance.com"

DEFAULT_SYMBOLS = [
    "BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT","XRPUSDT","ADAUSDT","DOGEUSDT","TRXUSDT","LINKUSDT","AVAXUSDT",
    "DOTUSDT","MATICUSDT","TONUSDT","LTCUSDT","BCHUSDT","UNIUSDT","NEARUSDT","APTUSDT","ARBUSDT","OPUSDT",
    "ETCUSDT","FILUSDT","ATOMUSDT","INJUSDT","SUIUSDT","SEIUSDT","AAVEUSDT","RNDRUSDT","PEPEUSDT","SHIBUSDT"
]

CATEGORIES = {
    "BTC":"主流幣", "ETH":"主流幣", "BNB":"平台幣", "SOL":"公鏈", "XRP":"支付", "ADA":"公鏈", "DOGE":"迷因幣",
    "TRX":"公鏈", "LINK":"Oracle", "AVAX":"公鏈", "DOT":"公鏈", "MATIC":"Layer2", "POL":"Layer2", "TON":"公鏈",
    "LTC":"主流幣", "BCH":"主流幣", "UNI":"DeFi", "NEAR":"公鏈", "APT":"公鏈", "ARB":"Layer2", "OP":"Layer2",
    "ETC":"主流幣", "FIL":"儲存", "ATOM":"公鏈", "INJ":"DeFi", "SUI":"公鏈", "SEI":"公鏈", "AAVE":"DeFi",
    "RNDR":"AI/算力", "RENDER":"AI/算力", "PEPE":"迷因幣", "SHIB":"迷因幣"
}

def http_json(path, params=None, timeout=20):
    url = BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent":"crypto-screener/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))

def symbol_base(sym):
    for q in ["USDT","USDC","BTC","ETH","FDUSD","TUSD"]:
        if sym.endswith(q): return sym[:-len(q)], q
    return sym, ""

def category(sym):
    base, quote = symbol_base(sym)
    return CATEGORIES.get(base, "其他")

def get_top_usdt(limit):
    info = http_json("/api/v3/exchangeInfo")
    valid = {s["symbol"] for s in info.get("symbols", []) if s.get("status") == "TRADING" and s.get("quoteAsset") == "USDT" and s.get("isSpotTradingAllowed", True)}
    tickers = http_json("/api/v3/ticker/24hr")
    rows = []
    for t in tickers:
        sym = t.get("symbol")
        if sym in valid:
            try: qv = float(t.get("quoteVolume", 0))
            except Exception: qv = 0
            rows.append((qv, sym))
    rows.sort(reverse=True)
    return [sym for _, sym in rows[:limit]]

def fetch_klines(symbol, interval, limit, sleep_sec):
    params = {"symbol":symbol, "interval":interval, "limit":limit}
    data = http_json("/api/v3/klines", params)
    out = []
    for k in data:
        ts = int(k[0]) / 1000
        dt = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        out.append({
            "symbol": symbol,
            "base": symbol_base(symbol)[0],
            "quote": symbol_base(symbol)[1],
            "category": category(symbol),
            "interval": interval,
            "date": dt,
            "open": k[1], "high": k[2], "low": k[3], "close": k[4],
            "volume": k[5], "quote_volume": k[7], "trades": k[8]
        })
    time.sleep(sleep_sec)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="", help="逗號分隔，例如 BTCUSDT,ETHUSDT")
    ap.add_argument("--top", type=int, default=80, help="依 24h quoteVolume 取前 N 個 USDT 現貨交易對")
    ap.add_argument("--interval", default="1d", choices=["1h","4h","1d"])
    ap.add_argument("--limit", type=int, default=160, help="每個交易對 K 線筆數")
    ap.add_argument("--out", default="crypto_history.csv")
    ap.add_argument("--sleep", type=float, default=0.2)
    args = ap.parse_args()
    if args.symbols.strip():
        symbols = [s.strip().upper() for s in args.symbols.split(',') if s.strip()]
    else:
        try:
            symbols = get_top_usdt(args.top)
        except Exception as e:
            print("取得熱門交易對失敗，改用預設清單：", e)
            symbols = DEFAULT_SYMBOLS[:args.top]
    print(f"共 {len(symbols)} 個交易對，interval={args.interval}, limit={args.limit}")
    fields = ["symbol","base","quote","category","interval","date","open","high","low","close","volume","quote_volume","trades"]
    ok = 0
    with open(args.out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for i, sym in enumerate(symbols, 1):
            try:
                rows = fetch_klines(sym, args.interval, args.limit, args.sleep)
                for r in rows: w.writerow(r)
                ok += 1
                print(f"[{i}/{len(symbols)}] {sym} OK（{len(rows)}筆）")
            except Exception as e:
                print(f"[{i}/{len(symbols)}] {sym} FAIL：{e}")
    print(f"完成：{ok}/{len(symbols)}，輸出 {args.out}")

if __name__ == "__main__": main()
