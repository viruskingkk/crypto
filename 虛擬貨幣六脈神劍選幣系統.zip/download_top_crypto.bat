@echo off
chcp 65001 >nul
python crypto_screener_downloader.py --top 100 --interval 1d --limit 160 --out crypto_history.csv --sleep 0.2
pause
