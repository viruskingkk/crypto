@echo off
chcp 65001 >nul
python crypto_screener_downloader.py --top 80 --interval 4h --limit 240 --out crypto_history_4h.csv --sleep 0.2
pause
